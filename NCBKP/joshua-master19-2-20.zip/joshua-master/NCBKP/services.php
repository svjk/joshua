<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v4.9.7, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/Logo.png" type="image/x-icon">
  <meta name="description" content="">
  
  <title>Swami Vivekananda Jnana Kendra</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
    <section class="menu cid-qTkzRZLJNu" once="menu" id="menu1-1k">
    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="index.php">
                         <img src="assets/images/Logo.png" alt="" style="height: 4.8rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap">
                    <a class="navbar-caption text-white display-4" href="https://mobirise.com">                        
                    </a>
                </span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true">
                <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="index.php">
                        Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="about.php">
                        About Us
                    </a>
                </li>
				 <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="services.php">
                        Educational Services
                    </a>
                </li>
				 <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="contact.php">
                        Contact Us
                    </a>
                </li>
            </ul>
            
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.info/g">Swami Vivekananda Jnana Kendra</a></section><section class="header1 cid-rm0rYIbKvu mbr-parallax-background" id="header1-1t">
<div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(20, 157, 204);">
    </div>

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">               
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2">
                   Swami Vivekananda Jnana Kendra
                </h3>
            </div>
        </div>
    </div>
</section>


<section class="testimonials5 cid-rm0tXaexBQ" id="testimonials5-20">
<div class="mbr-overlay" style="opacity: 0.8; background-color: rgb(193, 193, 193);">
    </div>
    <div class="container">
        <div class="media-container-row">
            <div class="title col-12 align-center">
                <h2 class="pb-3 mbr-fonts-style display-2">
                    Educational Services
                </h2>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="media-container-column">
        <div class="mbr-testimonial align-center col-12 col-md-10">
                <div class="panel-item">
                    <div class="card-block">
                        <div>
                            <h4>COACHING CLASSES</h4>
                        </div>
                        <p class="mbr-text mbr-fonts-style display-7">
                           1st to 12th Standards ICSE/CBSE/STATE/ISC/IGSE BOARDS: COMMERCE, SCIENCE and ARTS STREAMS
                        </p>
                    </div>                   
                </div>
            </div>
			<div class="mbr-testimonial align-center col-12 col-md-10">
                <div class="panel-item">
                    <div class="card-block">
                        <div>
                             <h4>GRADUATION</h4>
                        </div>
                        <p class="mbr-text mbr-fonts-style display-7">
                           B.Sc, B.Com, BCA, BBA, MBA, B.E (All Branches & All subjects) M.Tech
                        </p>
                    </div>
                </div>
            </div>
			<div class="mbr-testimonial align-center col-12 col-md-10">
                <div class="panel-item">
                    <div class="card-block">
                        <div>
                             <h4>TECHNICAL COURSES</h4>
                        </div>
                        <p class="mbr-text mbr-fonts-style display-7">
						<ul style="text-align:left;">
							<li>Basic Computers & Internet Skills</li>
							<li>OPERATING SYSTEMS : LINUX, WINDOWS</li>
							<li>Languages: C, C++ , JAVA, C#, VB.NET</li>
							<li>WEB/MOBILE APPS: Web, Android/iOS Applications Development</li>
							<li>SCRIPTING: SHELL, PERL, POWER-SHELL, PYTHON, RUBY ON RAILS</li>
							<li>Accounting Software : Tally, Quick Books</li>
							<li>Advanced Technologies: Big Data, Hadoop, Cloud Computing</li>
							<li>VERTICALS: .NET, JAVA</li>
							<li>EMBEDDED: MICROCONTROLLER ARM7, ARM9, 8051, POWER PC, DEVICE DRIVER ON LINUX</li>
							<li>LINUX COMMANDS, SHELL SCRIPTS, SYSTEMS PROGRAMMING, KERNEL PROGRAMMING, DEVICE DRIVERS</li>
						</ul>
                        </p>
                    </div>
                </div>
            </div>
			<div class="mbr-testimonial align-center col-12 col-md-10">
                <div class="panel-item">
                    <div class="card-block">
                        <div>
                             <h4>ENGLISH CERTIFICATION COURSES</h4>
                        </div>
                        <p class="mbr-text mbr-fonts-style display-7">
						<ul style="text-align:left;">
							<li>TOEFL</li>
							<li>IELTS</li>
							<li>Foundation English Module</li>
							<li>Intermediate Conversation Module</li>
							<li>Advanced Or Business English Module</li>
						</ul>
                        </p>
                    </div>
                </div>
            </div>
			<div class="mbr-testimonial align-center col-12 col-md-10">
                <div class="panel-item">
                    <div class="card-block">
                        <div>
                             <h4>ENGLISH CERTIFICATION COURSES</h4>
                        </div>
                        <p class="mbr-text mbr-fonts-style display-7">We are the hub of state and national level Engineering and Medical Entrance education in HENNUR – BENGALURU. We provide the “Daily Practice Problem (DPP) Sheets” for ENTRANCE EXAMS is precise, apt and tuned to all the requirements of standard state level entrance exams and JEE Mains / Advanced aspirant as we believe that student should prepare for these entrance exams regularly day in and day out.
						<ul style="text-align:left;">
							<li>CET</li>
							<li>AIMS</li>
							<li>NEET</li>
							<li>AIEEE</li>
							<li>IIT-JEE MAINS & ADVANCED</li>
						</ul>
                        </p>
                    </div>
                </div>
            </div>
		</div>
    </div>   
</section>


  

<section class="cid-rm0rlkkphC" id="footer1-1r">
    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-3">
                <div class="media-wrap">
                     <a href="#">
                        <img src="assets/images/Logo.png" alt="Mobirise">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Address
                </h5>
                <p class="mbr-text">
                    #184, Hennur Cross, Near Indian Academy College,Off Ring Road, Bengaluru-560043 Karnataka, India.
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Contacts
                </h5>
                <p class="mbr-text">
                    Email: svj.kendra@gmail.com
                    <br>Phone: 080-41722223
                    <br>Mobile No: 9741264243, 9731663600
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Quick Links
                </h5>
                <p class="mbr-text">
                    <a class="text-primary" href="about.html">About</a>
                    <br><a class="text-primary" href="services.html">Services</a>
                    <br><a class="text-primary" href="contact">Contact</a>
                </p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-8 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                        © Copyright 2019 Swami Vivekananda Jnana Kendra - All Rights Reserved
                    </p>
                </div>
                
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/vimeoplayer/jquery.mb.vimeo_player.js"></script>
  <script src="assets/mbr-flip-card/mbr-flip-card.js"></script>
  <script src="assets/bootstrapcarouselswipe/bootstrap-carousel-swipe.js"></script>
  <script src="assets/sociallikes/social-likes.js"></script>
  <script src="assets/mbr-tabs/mbr-tabs.js"></script>
  <script src="assets/ytplayer/jquery.mb.ytplayer.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/slidervideo/script.js"></script>
  
  
</body>
</html>