<?php include "header.php" ?>
<div class="fix-call">
  <button type="button" class="btn btn-info btn-lg call"><img src="smartphone.png" class="call-btn">8041722223,9741264243,9731663600       
  	
  </button>
</div>
<div class="fix-location">
  <button type="button" class="btn btn-info btn-lg location"><img src="location.png" class="location-btn"><span>#184, Hennur Cross, Near Indian Academy College, Off
Ring Road, Bengaluru-560043 Karnataka, India. </span>	     
  	
  </button>
</div>



<?php include "footer.php"?>