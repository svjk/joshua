<?php include "header.php" ?>
<div class="spacer"></div>
<div class="container">
	<div class="faculty_table">
		<table class="table">
			<thead>
				<tr>
					<th>Monday</th>
					<th>Tuesday</th>
					<th>Wednesday</th>
					<th>Thursday</th>
					<th>Friday</th>
					<th>Saturday</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>6:00pm-8:00pm</td>
					<td></td>
					<td>7:00pm-8:00pm</td>
					<td>10:00am-12:00pm</td>

				</tr>
			</tbody>
		</table>
	</div>
	<div>
		<button>Fix Demo</button>
	</div>
	
</div>

<?php include "footer.php"?>