<?php include "header.php" ?>

<form action="" id="select-any-one">
	<label>
		<input type="radio" name="signup_form_select" value="1" id="register_select_student" placeholder="Name" checked> Student	
	</label>
  	
  	<label>
  		<input type="radio" name="signup_form_select" id="register_select_faculty" value="2"> Faculty
  	</label>
  	
  	<label>
  		<input type="radio" name="signup_form_select" id="register_select_institute" value="3"> Institute
  	</label>
  
  

</form>



  <!-- <section class="contact-us">
	<div class="container">
		<div class="row">
			<div class="col-md-4 text-center">
				<div class="card">
					<div class="front front1"> 
						<h3>Students/Parents</h3>
					</div> 
					<div class="back">
						<p>
							<em>
								<b>Tell Us Your Tuition Needs:</b>
									Just fill few details about your home tuition needs
								</em>
							</p>
							<p>
								<em>
									<b>Get Free Demo:</b>
									Interested home tutors will apply for your home tuition and we will arrange a free demo class by our home tutor.
								</em>
							</p>
							<p>
								<em>
									<b>Confirm If You Like:</b>
									After the demo class, evaluate the teacher and if you are satisfied with tutors teaching abilities then confirm him.
								</em>
							</p>
					</div>   
				</div>	
			</div>
			<div class="col-md-4 text-center">
				<div class="card">
					<div class="front front2"> 
						<h3>Tutors/Institute</h3>
					</div> 
					<div class="back">
					<p>
  							<em>
  								<b>Create Profile:</b>
  								Advertise about yourself by creating your profile.
  							</em>
  						</p>
  						<p>
  							<em>
  								<b>Get Students:</b>
  								You can find students by searching tuition needs posted on our website which matches your profile. Apply tuitions relevant to you.
  							</em>
  						</p>
					</div>   
				</div>	
			</div>
			
			
			
		</div>
		
	</div>
</section>
 -->
 <?php include "footer.php" ?>