# joshua
This code is for website, which in iteself is a search engine.
Developed by SVJK-Bengaluru
